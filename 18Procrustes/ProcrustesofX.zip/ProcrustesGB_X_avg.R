library(tidyverse)
library(Matrix)
library(DescTools)
library(Clarity)
library(sf)
library(ggplot2)
library(grid)
library(plotly)

# setwd("~/Documents/MiniProject/Network_1_pc/18Procrustes")
# code from 16: matrixSVD script to get in the shp file

## Get the data
namedf=read.csv("LADS_list_GB.csv",header=TRUE) # names of all the LADs in GB, 380 total
colnames(namedf)[1] <- "index"
colnames(namedf)[2] <- "LAD"
namedf$index <- as.numeric(namedf$index)

# read in A matrices
allA= c()
for (year in 2005:2010){
  name = paste0("A_", year)
  filename = paste0("A_LAD_", year, "_GB.mtx")
  A = readMM(filename)
  A = as.matrix(A)
  eval(call("<-", as.name(name), A ))
  allA=cbind(allA, A) # makes the concatenated A
}

# Winsorize the concatenated A matrix
nrows = nrow(allA)
A_wins <- Winsorize(allA, minval = 0, probs=c(0,0.99))
A_wins <- as.matrix(A_wins, nrow=nrows)
# then log
A <- log10(A_wins+1)

### for the AConcWinsLog data:
SVD_ConcWinsLog <- svd(A)

### ADD COLOURS FOR THE LADs DEPENDING ON GEOGRAPHICAL POSITION
LAD11_shp <- read_sf('Local_Authority_Districts_December_2016_GCB_in_the_UK.shp')
LAD11_shp <- LAD11_shp %>%
  mutate(centroids = st_centroid(st_geometry(.))) # find centroids
LAD11_shp <-  cbind(LAD11_shp, st_coordinates(LAD11_shp$centroids)) # add X and Y for centroid
maxX = max(LAD11_shp$X)
maxY = max(LAD11_shp$Y)
minX = min(LAD11_shp$X)
minY = min(LAD11_shp$Y)
LAD11_shp$Xscaled = (LAD11_shp$X - minX)/(maxX-minX)# goes 0 to 1
LAD11_shp$Yscaled = (LAD11_shp$Y - minY)/(maxY-minY)

index = which(LAD11_shp$lad16nm == "Vale of Glamorgan")

# rename 'Vale of Glamorgan' in shp file to 'The Vale of Glamorgan' so that it matches
LAD11_shp[index, 3] <-  'The Vale of Glamorgan' 

# reorder rows of LAD11_shp to match the A matrices
LAD11_shp = merge(LAD11_shp, namedf, by.x="lad16nm", by.y="LAD")
LAD11_shp = LAD11_shp %>%
  arrange(index)

### ANIMATION STUFF 
animationData = cbind(SVD_ConcWinsLog$v[ , 1:4] , rep(c(2005:2010), each=n))
animationData = cbind(animationData, rep(LAD11_shp$Xscaled, 6), rep(LAD11_shp$Yscaled, 6), rep(namedf$LAD, 6))
animationData = as.data.frame(animationData)
colnames(animationData) = c("dim1", "dim2", "dim3", "dim4", "year", "Xscaled", "Yscaled", "LAD")
animationData$col = rgb(red=animationData$Xscaled, blue=animationData$Yscaled, green = 0.2 )

#### 13/12/2022 - NEW STUFF FOR PROCRUSTES TRANSFORMATION
animationData[, c("dim1", "dim2", "dim3", "dim4","Xscaled", "Yscaled")] <- sapply(animationData[, c("dim1", "dim2", "dim3", "dim4","Xscaled", "Yscaled")], as.numeric)
G <- as.matrix(animationData[ , c("Xscaled","Yscaled")])
G <- G[1:380,] # matrix of long and lat

# average embedding across all timepoints
avgX <- animationData %>% group_by(LAD) %>% 
  summarise(across(c("dim1", "dim2", "dim3", "dim4"), mean), 
            .groups = 'drop') %>% 
  as.data.frame()
avgX <- avgX[ , -1] # remove LAD column 
avgX <- as.matrix(avgX) #as matrix - n x 4 matrix


### DOING PROCRUSTES TRANSFORMATION

# Try some iterative algorithm
G_tilde_t1 <- cbind(G, rep(0,dim(G)[1]), rep(0,dim(G)[1])) # \tilde{G}_0 = [G G_0 ] # have to set tilde_G_0 outside of for loop
P_tilde_t <- as.matrix(rep(0, 4^2), nrow =4) # have to decide some P_tilde_0 for it to start from in the distance measure
dist = 10 # so it will start
P_tilde_tm1 <- P_tilde_t
while(dist > 1e-10){
  P_tilde_tm1 <- P_tilde_t #save P_tilde from the last iteration
  Proc <- MCMCpack::procrustes(avgX, G_tilde_t1)#, translation = TRUE, dilation = TRUE)
  P_tilde_t = Proc$R
  G_t1 = Proc$X.new[,3:4]
  G_tilde_t1 = cbind(G, G_t1)
  # dist between previous and current P_tilde
  dist <- norm((P_tilde_t - P_tilde_tm1), type="F")
  print(dist)
}

# X_tilde is the approximation of G 
X_tilde = avgX %*% P_tilde_t[, 1:2]
norm(G_t1-X_tilde)

# normalise X_tilde, so values go 0 to 1
normalisedX_tilde = as.data.frame(X_tilde[1:380, 1:2])
colnames(normalisedX_tilde)[1] <- "normd1"
colnames(normalisedX_tilde)[2] <- "normd2"
normalisedX_tilde = apply(normalisedX_tilde,2,function(x){x + abs(min(x))})
normalisedX_tilde = apply(normalisedX_tilde,2,function(x){x/max(x)})
normalisedX_tilde[normalisedX_tilde < 1/255] <- 0

LAD11_shp_avgX = cbind(LAD11_shp, normalisedX_tilde)
colnames(LAD11_shp_avgX)

# Read in LAD to opacity (connectivity outward (rowmeans) table)
# opacity_lookup_UK = read_csv("opacity_lookup_UK.csv")

# merge to LAD11_shp_avgX
LAD11_shp_avgX = merge(LAD11_shp_avgX, opacity_lookup_UK, by.x = "lad16nm", by.y="LAD", how="left" )
LAD11_shp_avgX <- LAD11_shp_avgX %>%
  mutate(centroids = st_centroid(st_geometry(.))) # find centroids

### map of UK coloured by 2D colourmap - filled 
ggplot(LAD11_shp_avgX) + geom_sf(aes(geometry=centroids), size=1,
                                  fill = rgb(red=LAD11_shp_avgX$normd1, blue=LAD11_shp_avgX$normd2, green = 0.2), 
                                  col=rgb(red=LAD11_shp_avgX$normd1, blue=LAD11_shp_avgX$normd2, green = 0.2),lwd=0.1) + 
  ggtitle("GB LADs map filled by 2D Procrustes\nX_avg") 
